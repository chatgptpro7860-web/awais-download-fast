const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const rootDir = path.resolve(__dirname, '..');
const binDir = path.join(rootDir, 'bin');
try {
  if (!fs.existsSync(binDir)) {
    fs.mkdirSync(binDir, { recursive: true });
  }
} catch (e) {}

// Find csc.exe compiler in standard Windows .NET directories
function findCscCompiler() {
  const possiblePaths = [
    'C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe',
    'C:\\Windows\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe',
    'C:\\Windows\\Microsoft.NET\\Framework64\\v3.5\\csc.exe',
    'C:\\Windows\\Microsoft.NET\\Framework\\v3.5\\csc.exe'
  ];

  for (const p of possiblePaths) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// C# source code for native Windows GUI Launcher (No black console flash!)
const launcherCSharpCode = `
using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace AwaisDownloadFast
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            string appDir = AppDomain.CurrentDomain.BaseDirectory;
            string serverScript = Path.Combine(appDir, "server.js");
            string port = "3000";
            string url = "http://localhost:" + port;

            bool isServerRunning = CheckServer(url);

            if (!isServerRunning)
            {
                // Find node.exe
                string nodePath = FindNodeExecutable();
                if (string.IsNullOrEmpty(nodePath))
                {
                    MessageBox.Show(
                        "Node.js is not installed or not in PATH.\\nPlease install Node.js from https://nodejs.org to use Awais Download Fast.",
                        "Awais Download Fast - Node.js Required",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    Process.Start("https://nodejs.org");
                    return;
                }

                if (File.Exists(serverScript))
                {
                    ProcessStartInfo psi = new ProcessStartInfo();
                    psi.FileName = nodePath;
                    psi.Arguments = "\\"" + serverScript + "\\"";
                    psi.WorkingDirectory = appDir;
                    psi.WindowStyle = ProcessWindowStyle.Hidden;
                    psi.CreateNoWindow = true;
                    psi.UseShellExecute = false;

                    try
                    {
                        Process.Start(psi);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Could not start server: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    // Wait up to 5 seconds for server to start
                    for (int i = 0; i < 10; i++)
                    {
                        Thread.Sleep(500);
                        if (CheckServer(url))
                        {
                            break;
                        }
                    }
                }
            }

            // Open browser to application URL
            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch (Exception)
            {
                Process.Start("explorer.exe", url);
            }
        }

        static bool CheckServer(string url)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url + "/api/health");
                request.Timeout = 1000;
                request.Method = "GET";
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    return response.StatusCode == HttpStatusCode.OK;
                }
            }
            catch
            {
                return false;
            }
        }

        static string FindNodeExecutable()
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("where", "node");
                psi.RedirectStandardOutput = true;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                using (Process p = Process.Start(psi))
                {
                    string output = p.StandardOutput.ReadToEnd();
                    p.WaitForExit();
                    if (!string.IsNullOrEmpty(output))
                    {
                        string[] lines = output.Split(new char[] { '\\r', '\\n' }, StringSplitOptions.RemoveEmptyEntries);
                        if (lines.Length > 0 && File.Exists(lines[0].Trim()))
                        {
                            return lines[0].Trim();
                        }
                    }
                }
            }
            catch { }

            string[] commonPaths = new string[] {
                @"C:\\Program Files\\nodejs\\node.exe",
                @"C:\\Program Files (x86)\\nodejs\\node.exe",
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\\Programs\\node\\node.exe"
            };

            foreach (var cp in commonPaths)
            {
                if (File.Exists(cp)) return cp;
            }

            return null;
        }
    }
}
`;

function compileExe() {
  const cscPath = findCscCompiler();
  if (!cscPath) {
    console.warn('[Build EXE] csc.exe compiler not found in standard .NET paths. Skipping C# compilation.');
    return false;
  }

  const srcPath = path.join(binDir, 'Launcher.cs');
  const targetExe = path.join(rootDir, 'Awais-Download-Fast.exe');
  const binTargetExe = path.join(binDir, 'Awais-Download-Fast.exe');

  fs.writeFileSync(srcPath, launcherCSharpCode, 'utf8');

  try {
    console.log('[Build EXE] Compiling native Windows executable launcher...');
    const cmd = `"${cscPath}" /target:winexe /out:"${targetExe}" /r:System.Windows.Forms.dll /r:System.dll "${srcPath}"`;
    execSync(cmd, { stdio: 'inherit' });

    // Also copy to bin directory
    fs.copyFileSync(targetExe, binTargetExe);
    fs.unlinkSync(srcPath);

    console.log(`[Build EXE] SUCCESS: Created native Windows launcher: ${targetExe}`);
    return true;
  } catch (err) {
    console.error('[Build EXE] Compilation error:', err.message);
    return false;
  }
}

if (require.main === module) {
  compileExe();
}

module.exports = { compileExe };
