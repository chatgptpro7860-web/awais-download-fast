const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const templatePath = path.join(rootDir, 'public', 'index.html');
const cssPath = path.join(rootDir, 'style.css');
const jsPath = path.join(rootDir, 'app.js');

let html = fs.readFileSync(templatePath, 'utf8');
const css = fs.readFileSync(cssPath, 'utf8');
const js = fs.readFileSync(jsPath, 'utf8');

// Inject CSS inside head
html = html.replace('</head>', `<style>\n${css}\n</style>\n</head>`);

// Inject JS before closing body
html = html.replace('</body>', `<script>\n${js}\n</script>\n</body>`);

fs.writeFileSync(path.join(rootDir, 'index.html'), html, 'utf8');
console.log('SUCCESS: Bundled AwaisX into index.html! File size: ' + html.length + ' bytes');
