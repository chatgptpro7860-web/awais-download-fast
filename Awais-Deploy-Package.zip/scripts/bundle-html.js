const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const templateHtml = fs.readFileSync(path.join(rootDir, 'public', 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(rootDir, 'style.css'), 'utf8');
const js = fs.readFileSync(path.join(rootDir, 'app.js'), 'utf8');

// Bundle into standalone index.html
let bundled = templateHtml;
bundled = bundled.replace('<link rel="stylesheet" href="style.css">', `<style>\n${css}\n</style>`);
bundled = bundled.replace('<script src="app.js"></script>', `<script>\n${js}\n</script>`);

fs.writeFileSync(path.join(rootDir, 'index.html'), bundled, 'utf8');
console.log('✅ BUNDLE SUCCESS! index.html created. Total size: ' + bundled.length + ' bytes');
