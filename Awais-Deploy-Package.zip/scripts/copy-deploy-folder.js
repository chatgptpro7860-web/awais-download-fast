const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const outDir = path.join(rootDir, 'github-vercel-files');

if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

function copyRecursive(src, dest) {
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    fs.readdirSync(src).forEach(child => {
      copyRecursive(path.join(src, child), path.join(dest, child));
    });
  } else {
    fs.copyFileSync(src, dest);
  }
}

// Copy Root Deploy Files
const files = [
  'index.html',
  'style.css',
  'app.js',
  'icon.svg',
  'manifest.json',
  'sw.js',
  'server.js',
  'index.js',
  'package.json',
  'vercel.json',
  '.gitignore',
  'README.md'
];

files.forEach(f => {
  const p = path.join(rootDir, f);
  if (fs.existsSync(p)) {
    fs.copyFileSync(p, path.join(outDir, f));
  }
});

// Copy api and public
copyRecursive(path.join(rootDir, 'api'), path.join(outDir, 'api'));
copyRecursive(path.join(rootDir, 'public'), path.join(outDir, 'public'));

console.log('✅ SUCCESS! github-vercel-files folder created with all latest files.');
