const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

const rootDir = path.resolve(__dirname, '..');
const zipPath = path.join(rootDir, 'Awais-Deploy-Package.zip');

const output = fs.createWriteStream(zipPath);
const archive = new archiver.ZipArchive({ zlib: { level: 9 } });

output.on('close', () => {
  console.log(`✅ SUCCESS! Created Awais-Deploy-Package.zip (${(archive.pointer() / 1024).toFixed(1)} KB)`);
});

archive.on('error', (err) => {
  throw err;
});

archive.pipe(output);

// Add Root Files
const rootFiles = [
  'index.html',
  'style.css',
  'app.js',
  'icon.svg',
  'manifest.json',
  'sw.js',
  'server.js',
  'index.js',
  'package.json',
  'vercel.json',
  '.gitignore',
  'README.md',
  'start.bat',
  'Start-Online-Link.bat',
  'Create-Desktop-Shortcut.bat'
];

rootFiles.forEach(file => {
  const fp = path.join(rootDir, file);
  if (fs.existsSync(fp)) {
    archive.file(fp, { name: file });
  }
});

// Add Directories
archive.directory(path.join(rootDir, 'api'), 'api');
archive.directory(path.join(rootDir, 'public'), 'public');
archive.directory(path.join(rootDir, 'scripts'), 'scripts');

archive.finalize();
