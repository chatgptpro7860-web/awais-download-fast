const fs = require('fs');
const path = require('path');
const https = require('https');
const { execSync } = require('child_process');

const BIN_DIR = path.join(__dirname, '..', 'bin');
const isWindows = process.platform === 'win32';
const BIN_NAME = isWindows ? 'yt-dlp.exe' : (process.platform === 'darwin' ? 'yt-dlp_macos' : 'yt-dlp');
const BIN_PATH = path.join(BIN_DIR, BIN_NAME);
const FFMPEG_PATH = path.join(BIN_DIR, isWindows ? 'ffmpeg.exe' : 'ffmpeg');

function downloadFile(url, dest) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Awais-Download-Fast' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return downloadFile(res.headers.location, dest).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`Failed to download: Status Code ${res.statusCode}`));
      }

      const totalSize = parseInt(res.headers['content-length'], 10) || 0;
      let downloaded = 0;
      let lastReport = 0;

      const file = fs.createWriteStream(dest);
      res.on('data', (chunk) => {
        downloaded += chunk.length;
        const now = Date.now();
        if (totalSize && now - lastReport > 800) {
          const percent = ((downloaded / totalSize) * 100).toFixed(1);
          const mb = (downloaded / (1024 * 1024)).toFixed(1);
          const totalMb = (totalSize / (1024 * 1024)).toFixed(1);
          process.stdout.write(`\r[Engine Setup] Downloading ${path.basename(dest)}: ${percent}% (${mb}/${totalMb} MB)`);
          lastReport = now;
        }
      });

      res.pipe(file);

      file.on('finish', () => {
        file.close(() => {
          console.log(`\n[Engine Setup] Successfully downloaded to ${dest}`);
          if (!isWindows) {
            try {
              fs.chmodSync(dest, 0o755);
            } catch (err) {}
          }
          resolve(dest);
        });
      });

      file.on('error', (err) => {
        fs.unlink(dest, () => {});
        reject(err);
      });
    }).on('error', (err) => {
      reject(err);
    });
  });
}

async function ensureFFmpeg() {
  if (fs.existsSync(FFMPEG_PATH)) {
    const stats = fs.statSync(FFMPEG_PATH);
    if (stats.size > 1000000) {
      return FFMPEG_PATH;
    }
  }

  if (isWindows) {
    const zipPath = path.join(BIN_DIR, 'ffmpeg.zip');
    const ffmpegUrl = 'https://github.com/yt-dlp/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip';
    console.log('[Engine Setup] Downloading FFmpeg for HD Video & Audio muxing...');
    try {
      await downloadFile(ffmpegUrl, zipPath);
      console.log('[Engine Setup] Extracting FFmpeg...');
      const extractCmd = `powershell -Command "Expand-Archive -Path '${zipPath}' -DestinationPath '${BIN_DIR}\\temp_ffmpeg' -Force"`;
      execSync(extractCmd, { stdio: 'inherit' });

      // Move ffmpeg.exe and ffprobe.exe
      const tempBin = path.join(BIN_DIR, 'temp_ffmpeg');
      const subdirs = fs.readdirSync(tempBin);
      for (const subdir of subdirs) {
        const subBin = path.join(tempBin, subdir, 'bin');
        if (fs.existsSync(subBin)) {
          if (fs.existsSync(path.join(subBin, 'ffmpeg.exe'))) {
            fs.copyFileSync(path.join(subBin, 'ffmpeg.exe'), path.join(BIN_DIR, 'ffmpeg.exe'));
          }
          if (fs.existsSync(path.join(subBin, 'ffprobe.exe'))) {
            fs.copyFileSync(path.join(subBin, 'ffprobe.exe'), path.join(BIN_DIR, 'ffprobe.exe'));
          }
        }
      }

      // Cleanup temp
      try {
        fs.rmSync(path.join(BIN_DIR, 'temp_ffmpeg'), { recursive: true, force: true });
        fs.unlinkSync(zipPath);
      } catch (e) {}

      console.log('[Engine Setup] FFmpeg installed successfully.');
      return FFMPEG_PATH;
    } catch (err) {
      console.warn('[Engine Setup Warning] FFmpeg setup failed:', err.message);
      return null;
    }
  }
  return null;
}

async function ensureEngine() {
  try {
    if (!fs.existsSync(BIN_DIR)) {
      fs.mkdirSync(BIN_DIR, { recursive: true });
    }

    if (!fs.existsSync(BIN_PATH) || fs.statSync(BIN_PATH).size < 1000000) {
      console.log(`[Engine Setup] Downloading latest yt-dlp core engine for ${process.platform}...`);
      const downloadUrl = isWindows 
        ? 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe'
        : (process.platform === 'darwin' 
            ? 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos' 
            : 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp');

      try {
        await downloadFile(downloadUrl, BIN_PATH);
      } catch (err) {
        console.error(`[Engine Setup Warning] Direct download error: ${err.message}`);
      }
    }

    // Ensure FFmpeg in background if not present
    ensureFFmpeg().catch(() => {});
  } catch (e) {
    console.warn('[Engine Init Warning]:', e.message);
  }

  return BIN_PATH;
}

if (require.main === module) {
  ensureEngine().then(() => {
    return ensureFFmpeg();
  }).then(() => {
    console.log('[Engine Setup] All core engines ready!');
  }).catch((err) => {
    console.error('[Engine Setup Error]:', err);
  });
}

module.exports = {
  ensureEngine,
  ensureFFmpeg,
  BIN_PATH,
  FFMPEG_PATH,
  BIN_DIR
};
