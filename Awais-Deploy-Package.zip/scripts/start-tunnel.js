const { spawn } = require('child_process');
const http = require('http');

console.log(`
=====================================================
  ⚡ AWAISX - ONLINE LIVE SHARING LINK ⚡
=====================================================
  [1/2] Connecting to Cloudflare Global Network...
=====================================================
`);

// Check if server is running, if not start it
function checkAndStartServer() {
  return new Promise((resolve) => {
    http.get('http://localhost:3000/api/health', (res) => {
      resolve();
    }).on('error', () => {
      console.log('  Starting AwaisX local server...');
      const srv = spawn('node', ['server.js'], { detached: true, stdio: 'ignore' });
      srv.unref();
      setTimeout(resolve, 2000);
    });
  });
}

checkAndStartServer().then(() => {
  const cf = spawn('npx', ['cloudflared', 'tunnel', '--url', 'http://localhost:3000'], { shell: true });
  let urlFound = false;

  cf.stderr.on('data', (data) => {
    const text = data.toString();
    const match = text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
    if (match && !urlFound) {
      urlFound = true;
      const liveUrl = match[0];
      console.log(`
=====================================================
  🎉 SUCCESS! AAPKA LIVE ONLINE AWAISX LINK READY HAI:
=====================================================

  👉 ${liveUrl}

=====================================================
  Yeh link copy karke direct apne dost ko WhatsApp par 
  bhej dein. Woh mobile ya PC par video download 
  kar sakega! (Jab tak yeh window khuli rahegi)
=====================================================
`);
      // Copy to clipboard
      try {
        const pb = spawn('clip', [], { shell: true });
        pb.stdin.write(liveUrl);
        pb.stdin.end();
        console.log('  [Link automatically clipboard me COPY ho gaya hai!]');
      } catch (e) {}
    }
  });

  cf.on('close', () => {
    console.log('Online link stopped.');
  });
});
